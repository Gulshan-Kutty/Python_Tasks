# Print Hello, World!

var = 'Hello, World!'
print(var)